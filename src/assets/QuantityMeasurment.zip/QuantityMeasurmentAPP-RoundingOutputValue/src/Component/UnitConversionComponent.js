import React, { Component } from 'react';
import { View, Text, TextInput, } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import {UnitsAndCorrespondingValue} from '../Component/UnitsAndCorrespondingValue'
import unitConversionBlockStyles from '../Style/unitConversionBlockStyles';
export default class UnitConversionBlock extends Component {
    constructor(props) {
        super(props)        
        this.state = {
            lengthUnits: UnitsAndCorrespondingValue.lengthUnits,
            lengthValues: UnitsAndCorrespondingValue.lengthValues,
            tempertureUnits: UnitsAndCorrespondingValue.tempertureUnits,
            tempertureValues: UnitsAndCorrespondingValue.tempertureValues,
            volumeUnits: UnitsAndCorrespondingValue.volumeUnits,
            volumeValues: UnitsAndCorrespondingValue.volumeValues,
            selectedInputUnit: 0,
            selectedOutputUnit: 0,
            enteredValue: '',
            outputValue: '',
        }                                                                                           
    }

    inputUnitHandler = async (selectedInputUnitType) => {
        await this.setState({
            selectedInputUnit: selectedInputUnitType
        })
        this.inputValueHandler(this.state.enteredValue)

    }

    outputUnitHandler = async (selectedOutputUnitType) => {
        await this.setState({
            selectedOutputUnit: selectedOutputUnitType
        })
        this.inputValueHandler(this.state.enteredValue)
    }

    inputValueHandler = async (value) => {
        await this.setState({
            enteredValue: value
        })
        if (this.props.type == 'Length') {
            var inputUnit = parseFloat(this.state.selectedInputUnit);
            var outputUnit = parseFloat(this.state.selectedOutputUnit);
            var valueEntered = parseFloat(this.state.enteredValue);

            this.setState({
                outputValue: (valueEntered * this.state.lengthValues[inputUnit]) / this.state.lengthValues[outputUnit]
            })
        }
        else if (this.props.type == 'Volume') {
            var inputUnit = parseFloat(this.state.selectedInputUnit);
            var outputUnit = parseFloat(this.state.selectedOutputUnit);
            var valueEntered = parseFloat(this.state.enteredValue);

            this.setState({
                outputValue: (valueEntered * this.state.volumeValues[inputUnit]) / this.state.volumeValues[outputUnit]
            })
        }
        else if (this.props.type == 'Temperature') {
            var valueEntered = parseFloat(this.state.enteredValue);
            var inputUnit = this.state.tempertureValues[this.state.selectedInputUnit];
            var outputUnit = this.state.tempertureValues[this.state.selectedOutputUnit];

            if (inputUnit === 'C' && outputUnit === 'F') {
                this.setState({
                    outputValue: (valueEntered * 1.8) + 32
                })
            }
            else if (inputUnit === 'C' && outputUnit === 'K') {
                this.setState({
                    outputValue: valueEntered + 273.15
                })
            }
            else if (inputUnit === 'F' && outputUnit === 'C') {
                this.setState({
                    outputValue: (valueEntered - 32) * (5 / 9)
                })
            }
            else if (inputUnit === 'F' && outputUnit === 'K') {
                this.setState({
                    outputValue: (valueEntered - 32) * (5 / 9) + 273.15
                })
            }
            else if (inputUnit === 'K' && outputUnit === 'C') {
                this.setState({
                    outputValue: valueEntered - 273.15
                })
            }
            else if (inputUnit === 'K' && outputUnit === 'F') {
                this.setState({
                    outputValue: (valueEntered - 273.15) * (9 / 5) + 32
                })
            }
            else if (inputUnit === outputUnit)
                this.setState({
                    outputValue: valueEntered
                })
        }
        this.setState ({
             outputValue : Number(Math.round(this.state.outputValue + 'e4')+'e-4')
         })

    }

    render() {
        return (
            <View style={unitConversionBlockStyles.container}>
                <Text style={unitConversionBlockStyles.from_To}>From :</Text>
                <View style={{ flexDirection: 'column' }}>
                    <TextInput
                        placeholder={'Enter Unit Value'}
                        placeholderTextColor='#303236'
                        onChangeText={(value) => this.inputValueHandler(value)}
                        style={unitConversionBlockStyles.text_input}
                    />

                    <View style={unitConversionBlockStyles.picker_Style}>
                        <Picker
                            selectedValue={this.state.selectedInputUnit}
                            onValueChange={(selectedUnit) => this.inputUnitHandler(selectedUnit)}
                            mode="dropdown">

                            {(this.props.type == 'Length') ?
                                this.state.lengthUnits.map((unit, index) => {
                                    return (<Picker.Item label={unit} value={index} key={unit} />)
                                }) : (this.props.type == 'Temperature') ?
                                    this.state.tempertureUnits.map((unit, index) => {
                                        return (<Picker.Item label={unit} value={index} key={unit} />)
                                    }) : this.state.volumeUnits.map((unit, index) => {
                                        return (<Picker.Item label={unit} value={index} key={unit} />)
                                    })
                            }

                        </Picker>
                    </View>
                </View>

                <Text style={unitConversionBlockStyles.from_To}>To :</Text>
                <View style={{ flexDirection: 'column' }}>
                    <TextInput
                        placeholder={'Output Unit'}
                        value={(this.state.outputValue.toString() != 'NaN') ? this.state.outputValue.toString() : '0'}
                        editable={false}
                        style={unitConversionBlockStyles.text_input}

                    />

                    <View style={unitConversionBlockStyles.picker_Style}>
                        <Picker
                            selectedValue={this.state.selectedOutputUnit}
                            onValueChange={(selectedUnit) => this.outputUnitHandler(selectedUnit)}
                            mode="dropdown">

                            {(this.props.type == 'Length') ?
                                this.state.lengthUnits.map((unit, index) => {
                                    return (<Picker.Item label={unit} value={index} key={unit} />)
                                }) : (this.props.type == 'Temperature') ?
                                    this.state.tempertureUnits.map((unit, index) => {
                                        return (<Picker.Item label={unit} value={index} key={unit} />)
                                    }) : this.state.volumeUnits.map((unit, index) => {
                                        return (<Picker.Item label={unit} value={index} key={unit} />)
                                    })
                            }

                        </Picker>
                    </View>
                </View>
            </View>
        )
    }
}
